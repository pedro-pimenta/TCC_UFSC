#include <stdio.h>
#include <stdlib.h>

void problem();
