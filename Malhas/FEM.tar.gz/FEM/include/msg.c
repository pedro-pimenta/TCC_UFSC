#include "msg.h"

void problem(){
   printf("Erro: Insufficient memory!!!\n");
   exit(1);
}
