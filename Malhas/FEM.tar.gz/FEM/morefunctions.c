double g(double x, double y){
return 4.;
}

double Ug(double x, double y){
return x*x+y*y;
}

double g1(double x, double y){
return x*x;   /*Dirichlet*/
}

double g2(double x, double y){
return 2.*x;  /*Newman*/
}

double g3(double x, double y){
return x*x + 1.;  /*Dirichlet*/
}

double g4(double x, double y){
return y*y;  /*Dirichlet */
}

double g5(double x, double y){
return 0.0;
}




