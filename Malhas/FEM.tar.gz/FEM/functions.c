#include <math.h>

double f(double x, double y){
return -2.*cos(x)*sin(y);
}

double U(double x, double y){
return cos(x)*sin(y);
}

double f1(double x, double y){
return 0.;
}

double f2(double x, double y){
return   -sin(1.)*sin(y);
}

double f3(double x, double y){
return cos(1.)*cos(x);
}

double f4(double x, double y){
return sin(y);
}





